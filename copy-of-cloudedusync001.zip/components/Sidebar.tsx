import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Users, UserPlus, CreditCard, Building, LogOut, BookOpen, GraduationCap, DollarSign } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';
import { motion } from 'framer-motion';

const Sidebar: React.FC = () => {
  const { user, logout } = useApp();

  if (!user) return null;

  const adminLinks = [
    { name: 'Overview', path: '/', icon: LayoutDashboard },
    { name: 'Student Management', path: '/students', icon: Users },
    { name: 'Admissions', path: '/admission', icon: UserPlus },
    { name: 'Fee Management', path: '/fees', icon: CreditCard },
    { name: 'Hostel Allocation', path: '/hostel', icon: Building },
  ];

  const facultyLinks = [
    { name: 'Faculty Dashboard', path: '/', icon: LayoutDashboard },
    { name: 'My Students', path: '/students', icon: Users },
    { name: 'Mark Attendance', path: '/admission', icon: UserPlus }, // Reusing admission for demo flow
  ];

  // Student portal has internal tabs, but we provide a dashboard link
  const studentLinks = [
    { name: 'My Portal', path: '/', icon: LayoutDashboard },
  ];

  let links = [];
  let portalName = "";
  let headerGradient = "";

  switch (user.role) {
    case UserRole.ADMIN:
      links = adminLinks;
      portalName = "Admin Portal";
      headerGradient = "from-blue-600 to-indigo-700";
      break;
    case UserRole.FACULTY:
      links = facultyLinks;
      portalName = "Faculty Portal";
      headerGradient = "from-violet-600 to-fuchsia-700";
      break;
    case UserRole.STUDENT:
      links = studentLinks;
      portalName = "Student Portal";
      headerGradient = "from-emerald-500 to-teal-600";
      break;
  }

  return (
    <motion.aside 
      initial={{ x: -50, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      className="w-64 bg-white border-r border-gray-200 min-h-screen flex flex-col fixed left-0 top-0 bottom-0 z-20 shadow-lg"
    >
      {/* Gradient Header */}
      <div className={`h-20 flex items-center px-6 bg-gradient-to-r ${headerGradient} text-white`}>
        <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center mr-3 shadow-sm border border-white/30">
          <span className="font-bold text-xl">C</span>
        </div>
        <div>
          <h1 className="font-bold text-lg leading-tight">CloudEduSync</h1>
          <p className="text-xs text-white/80 font-medium tracking-wide">ERP SYSTEM</p>
        </div>
      </div>

      <div className="p-4 flex-1 overflow-y-auto">
        <div className="mb-6 px-2">
          <p className="text-xs text-gray-500 uppercase font-bold tracking-wider">{portalName}</p>
        </div>
        <nav className="space-y-1.5">
          {links.map((link) => (
            <NavLink
              key={link.name}
              to={link.path}
              className={({ isActive }) =>
                `flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-gray-50 text-blue-700 border-l-4 border-blue-600 shadow-sm'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900 hover:pl-5'
                }`
              }
            >
              <link.icon className={`w-5 h-5 mr-3 ${link.path === location.pathname ? 'text-blue-600' : 'text-gray-400'}`} />
              {link.name}
            </NavLink>
          ))}
        </nav>
      </div>

      <div className="p-4 border-t border-gray-100 bg-gray-50/50">
        <div className="flex items-center p-2 mb-3 bg-white rounded-lg border border-gray-100 shadow-sm">
          <div className={`w-9 h-9 rounded-full bg-gradient-to-br ${headerGradient} flex items-center justify-center text-sm font-bold text-white shadow-sm`}>
            {user.name.charAt(0)}
          </div>
          <div className="ml-3 overflow-hidden">
            <p className="text-sm font-semibold text-gray-700 truncate">{user.name}</p>
            <p className="text-xs text-gray-500 truncate capitalize">{user.role.toLowerCase()}</p>
          </div>
        </div>
        <button
          onClick={logout}
          className="flex w-full items-center justify-center px-4 py-2 text-sm text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition-colors font-medium"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Sign Out
        </button>
      </div>
    </motion.aside>
  );
};

export default Sidebar;