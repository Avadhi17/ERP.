export enum UserRole {
  ADMIN = 'ADMIN',
  FACULTY = 'FACULTY',
  STUDENT = 'STUDENT'
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  email: string;
  avatar?: string;
  department?: string; // For Faculty
  program?: string; // For Students
}

export interface Student {
  id: string; // STU-2023-001
  fullName: string;
  email: string;
  phone: string;
  course: string;
  batchYear: string;
  admissionDate: string;
  totalFees: number;
  feesPaid: number;
  feeStatus: 'PAID' | 'PARTIAL' | 'UNPAID';
  hostelRequired: boolean;
  hostelRoom: string | null;
  // Extended Data for Student Portal
  gpa: number;
  attendance: number;
  performance: 'Excellent' | 'Good' | 'Average' | 'Poor';
}

export interface SubjectPerformance {
  subject: string;
  professor: string;
  grade: string;
  attendance: number;
  status: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  totalClasses: number;
  attendedClasses: number;
}

export interface Assignment {
  id: string;
  title: string;
  subject: string;
  dueDate: string;
  status: 'Pending' | 'Submitted' | 'Graded';
  score?: string;
}

export interface LibraryBook {
  title: string;
  author: string;
  issuedDate: string;
  dueDate: string;
  status: 'Active' | 'Overdue' | 'Returned';
}

export interface FacultySchedule {
  id: string;
  time: string;
  subject: string;
  room: string;
  batch: string;
  type: 'Lecture' | 'Lab' | 'Tutorial';
}

export interface DashboardStats {
  totalStudents: number;
  admissionsToday: number;
  totalFeesCollected: number;
  hostelOccupancy: number;
  avgAttendance: number;
  avgGPA: number;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
}