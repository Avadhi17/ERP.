import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserRole, Student, DashboardStats } from '../types';
import { ApiService } from '../services/api';

interface AppContextType {
  user: User | null;
  login: (email: string, role: UserRole) => void;
  logout: () => void;
  students: Student[];
  stats: DashboardStats | null;
  refreshData: () => Promise<void>;
  isLoading: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('ces_user');
    return saved ? JSON.parse(saved) : null;
  });
  
  const [students, setStudents] = useState<Student[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const login = (email: string, role: UserRole) => {
    const nameMap: Record<UserRole, string> = {
      [UserRole.ADMIN]: 'Admin User',
      [UserRole.FACULTY]: 'Faculty Member',
      [UserRole.STUDENT]: 'Rahul Sharma' // Matching mock student ID STU-2024-001
    };

    const newUser: User = {
      id: role === UserRole.STUDENT ? 'STU-2024-001' : 'U-1',
      name: nameMap[role],
      role,
      email: email
    };
    setUser(newUser);
    localStorage.setItem('ces_user', JSON.stringify(newUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('ces_user');
  };

  const refreshData = async () => {
    // We fetch data even if user is not set initially to have data ready, 
    // but typically we want it protected. For MVP we allow fetch.
    try {
      // Don't set global loading spinner on background refreshes
      const [studentData, statsData] = await Promise.all([
        ApiService.getStudents(),
        ApiService.getDashboardStats()
      ]);
      setStudents(studentData);
      setStats(statsData);
    } catch (err) {
      console.error(err);
    }
  };

  // Initial Load
  useEffect(() => {
    const init = async () => {
      setIsLoading(true);
      await refreshData();
      setIsLoading(false);
    };
    if (user) init();
  }, [user]);

  // Auto-Poll for "Real-Time" updates every 5 seconds
  useEffect(() => {
    if (!user) return;
    const interval = setInterval(() => {
      refreshData();
    }, 5000);
    return () => clearInterval(interval);
  }, [user]);

  return (
    <AppContext.Provider value={{ user, login, logout, students, stats, refreshData, isLoading }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};