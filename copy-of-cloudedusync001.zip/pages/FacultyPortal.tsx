
import React from 'react';
import { useApp } from '../context/AppContext';
import { Calendar, Users, ClipboardList, BookOpen, Clock } from 'lucide-react';
import { MOCK_FACULTY_SCHEDULE } from '../services/mockData';
import { UserRole } from '../types';

const FacultyPortal: React.FC = () => {
  const { user, students } = useApp();

  if (user?.role !== UserRole.FACULTY) return null;

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Faculty Dashboard</h1>
        <p className="text-gray-500">Overview of your schedule, classes, and student performance.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Schedule */}
        <div className="lg:col-span-2 space-y-8">
           {/* Today's Schedule */}
           <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center justify-between mb-6">
                 <h2 className="text-lg font-bold text-gray-900 flex items-center">
                    <Calendar className="w-5 h-5 mr-2 text-blue-600" />
                    Today's Schedule
                 </h2>
                 <span className="text-xs font-semibold bg-blue-50 text-blue-700 px-3 py-1 rounded-full">
                    {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
                 </span>
              </div>
              
              <div className="space-y-4">
                 {MOCK_FACULTY_SCHEDULE.map((slot) => (
                    <div key={slot.id} className="flex items-start p-4 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors">
                       <div className="w-24 flex-shrink-0 text-center border-r border-gray-100 pr-4">
                          <p className="text-sm font-bold text-gray-900">{slot.time.split(' ')[0]}</p>
                          <p className="text-xs text-gray-500">{slot.time.split(' ')[1]}</p>
                       </div>
                       <div className="ml-4 flex-1">
                          <div className="flex justify-between items-start">
                             <div>
                                <h3 className="text-sm font-bold text-gray-900">{slot.subject}</h3>
                                <p className="text-xs text-gray-500 mt-1">Room: {slot.room} • Batch: {slot.batch}</p>
                             </div>
                             <span className={`text-xs px-2 py-1 rounded border ${
                                slot.type === 'Lecture' ? 'bg-purple-50 text-purple-700 border-purple-100' : 
                                slot.type === 'Lab' ? 'bg-amber-50 text-amber-700 border-amber-100' : 
                                'bg-emerald-50 text-emerald-700 border-emerald-100'
                             }`}>
                                {slot.type}
                             </span>
                          </div>
                       </div>
                    </div>
                 ))}
              </div>
           </div>

           {/* Quick Actions for Class Management */}
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow cursor-pointer group">
                 <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <Users className="w-6 h-6" />
                 </div>
                 <h3 className="font-bold text-gray-900">Mark Attendance</h3>
                 <p className="text-sm text-gray-500 mt-1">Record student attendance for today's active classes.</p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow cursor-pointer group">
                 <div className="w-12 h-12 bg-violet-100 text-violet-600 rounded-lg flex items-center justify-center mb-4 group-hover:bg-violet-600 group-hover:text-white transition-colors">
                    <ClipboardList className="w-6 h-6" />
                 </div>
                 <h3 className="font-bold text-gray-900">Upload Marks</h3>
                 <p className="text-sm text-gray-500 mt-1">Enter marks for completed exams and assignments.</p>
              </div>
           </div>
        </div>

        {/* Right Column: Summaries */}
        <div className="space-y-6">
           {/* Class Stats */}
           <div className="bg-gradient-to-br from-indigo-600 to-violet-700 rounded-xl p-6 text-white shadow-lg">
              <h3 className="font-bold text-lg mb-4">Class Summary</h3>
              <div className="space-y-4">
                 <div className="flex justify-between items-center pb-3 border-b border-white/20">
                    <span className="text-indigo-100 text-sm">Total Classes Today</span>
                    <span className="font-bold text-xl">3</span>
                 </div>
                 <div className="flex justify-between items-center pb-3 border-b border-white/20">
                    <span className="text-indigo-100 text-sm">Avg. Attendance</span>
                    <span className="font-bold text-xl">88%</span>
                 </div>
                 <div className="flex justify-between items-center">
                    <span className="text-indigo-100 text-sm">Pending Grading</span>
                    <span className="font-bold text-xl text-amber-300">12</span>
                 </div>
              </div>
           </div>

           {/* Recent Submissions */}
           <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h3 className="font-bold text-gray-900 mb-4 text-sm uppercase tracking-wider">Recent Submissions</h3>
              <ul className="space-y-3">
                 {[1,2,3].map(i => (
                    <li key={i} className="flex items-center text-sm">
                       <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-xs font-bold text-gray-600 mr-3">
                          {String.fromCharCode(64+i)}
                       </div>
                       <div className="flex-1">
                          <p className="font-medium text-gray-800">Student {i}</p>
                          <p className="text-xs text-gray-400">DSA Assignment 5</p>
                       </div>
                       <span className="text-xs text-blue-600 font-medium cursor-pointer hover:underline">Grade</span>
                    </li>
                 ))}
              </ul>
              <button className="w-full mt-4 text-center text-sm text-gray-500 hover:text-blue-600">View All</button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default FacultyPortal;
