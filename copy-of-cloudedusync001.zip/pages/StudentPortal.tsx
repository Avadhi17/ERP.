
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  BookOpen, Clock, Award, DollarSign, Home, CheckCircle, 
  AlertTriangle, Calendar, Download, ChevronRight 
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { MOCK_STUDENT_PERFORMANCE, MOCK_ASSIGNMENTS, MOCK_LIBRARY_BOOKS } from '../services/mockData';
import { CURRENCY_FORMATTER } from '../constants';
import { UserRole } from '../types';

const StudentPortal: React.FC = () => {
  const { user, students } = useApp();
  const [activeTab, setActiveTab] = useState<'dashboard' | 'academics' | 'finances' | 'library' | 'hostel'>('dashboard');

  if (user?.role !== UserRole.STUDENT) return null;

  // Simulate logged-in student data
  const studentData = students.find(s => s.id === 'STU-2024-001') || students[0];

  const TabButton: React.FC<{ id: string; label: string; icon: any }> = ({ id, label, icon: Icon }) => (
    <button
      onClick={() => setActiveTab(id as any)}
      className={`flex items-center space-x-2 px-6 py-3 border-b-2 text-sm font-medium transition-colors ${
        activeTab === id 
          ? 'border-blue-600 text-blue-600' 
          : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
      }`}
    >
      <Icon className="w-4 h-4" />
      <span>{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-gray-50 p-6 md:p-8">
      {/* Header Profile Section */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8 flex flex-col md:flex-row items-center justify-between">
        <div className="flex items-center mb-4 md:mb-0">
          <div className="w-16 h-16 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-2xl font-bold">
            {studentData.fullName.charAt(0)}
          </div>
          <div className="ml-5">
            <h1 className="text-2xl font-bold text-gray-900">Welcome, {studentData.fullName}</h1>
            <p className="text-gray-500">{studentData.course} • Batch {studentData.batchYear} • {studentData.id}</p>
          </div>
        </div>
        <div className="flex gap-3">
          <div className="text-right px-4 border-r border-gray-200">
             <p className="text-xs text-gray-500 uppercase">Current GPA</p>
             <p className="text-xl font-bold text-emerald-600">{studentData.gpa}</p>
          </div>
          <div className="text-right px-4">
             <p className="text-xs text-gray-500 uppercase">Attendance</p>
             <p className="text-xl font-bold text-blue-600">{studentData.attendance}%</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-t-xl shadow-sm border-b border-gray-200 px-2 flex overflow-x-auto mb-6">
        <TabButton id="dashboard" label="Dashboard" icon={Home} />
        <TabButton id="academics" label="Academics" icon={Award} />
        <TabButton id="finances" label="Finances" icon={DollarSign} />
        <TabButton id="library" label="Library" icon={BookOpen} />
        <TabButton id="hostel" label="Hostel" icon={Home} />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {/* DASHBOARD TAB */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* Quick Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                 <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100">
                    <p className="text-sm text-gray-500 mb-1">Assignment Due</p>
                    <p className="text-2xl font-bold text-gray-900">2</p>
                    <p className="text-xs text-amber-600 mt-2 font-medium">Coming up in 3 days</p>
                 </div>
                 <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100">
                    <p className="text-sm text-gray-500 mb-1">Fee Status</p>
                    <p className={`text-xl font-bold ${studentData.feeStatus === 'PAID' ? 'text-emerald-600' : 'text-red-500'}`}>
                      {studentData.feeStatus}
                    </p>
                    <p className="text-xs text-gray-400 mt-2">Next due: Jan 15</p>
                 </div>
                 <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100">
                    <p className="text-sm text-gray-500 mb-1">Library Books</p>
                    <p className="text-2xl font-bold text-gray-900">2</p>
                    <p className="text-xs text-red-500 mt-2 font-medium">1 Overdue</p>
                 </div>
                 <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100">
                    <p className="text-sm text-gray-500 mb-1">Hostel</p>
                    <p className="text-lg font-bold text-gray-900">{studentData.hostelRoom || 'Not Allocated'}</p>
                    <p className="text-xs text-gray-400 mt-2">Block A</p>
                 </div>
              </div>

              {/* Assignments Table */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                  <Clock className="w-5 h-5 mr-2 text-blue-500" /> 
                  Upcoming Deadlines
                </h2>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-gray-50 text-gray-500 uppercase">
                      <tr>
                        <th className="px-4 py-3">Assignment</th>
                        <th className="px-4 py-3">Subject</th>
                        <th className="px-4 py-3">Due Date</th>
                        <th className="px-4 py-3">Status</th>
                        <th className="px-4 py-3">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {MOCK_ASSIGNMENTS.map((asg) => (
                        <tr key={asg.id}>
                          <td className="px-4 py-3 font-medium text-gray-900">{asg.title}</td>
                          <td className="px-4 py-3 text-gray-600">{asg.subject}</td>
                          <td className="px-4 py-3 text-gray-600">{asg.dueDate}</td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                              asg.status === 'Pending' ? 'bg-amber-100 text-amber-700' : 
                              asg.status === 'Graded' ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'
                            }`}>
                              {asg.status}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <button className="text-blue-600 hover:text-blue-800 text-xs font-medium border border-blue-200 px-3 py-1 rounded hover:bg-blue-50">
                              View
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ACADEMICS TAB */}
          {activeTab === 'academics' && (
            <div className="space-y-6">
               <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-lg font-bold text-gray-900 mb-4">Current Semester Performance</h2>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-gray-50 text-gray-500 uppercase">
                      <tr>
                        <th className="px-4 py-3">Subject</th>
                        <th className="px-4 py-3">Professor</th>
                        <th className="px-4 py-3">Grade</th>
                        <th className="px-4 py-3">Attendance</th>
                        <th className="px-4 py-3">Performance</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {MOCK_STUDENT_PERFORMANCE.map((sub, idx) => (
                        <tr key={idx}>
                          <td className="px-4 py-3 font-medium text-gray-900">{sub.subject}</td>
                          <td className="px-4 py-3 text-gray-600">{sub.professor}</td>
                          <td className="px-4 py-3 font-bold text-gray-800">{sub.grade}</td>
                          <td className="px-4 py-3">
                            <div className="flex items-center">
                              <span className={`font-bold mr-2 ${sub.attendance < 75 ? 'text-red-500' : 'text-emerald-600'}`}>
                                {sub.attendance}%
                              </span>
                              <div className="w-16 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                                <div className={`h-full ${sub.attendance < 75 ? 'bg-red-500' : 'bg-emerald-500'}`} style={{ width: `${sub.attendance}%` }}></div>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                              sub.status === 'Excellent' ? 'bg-emerald-100 text-emerald-700' :
                              sub.status === 'Good' ? 'bg-blue-100 text-blue-700' :
                              'bg-amber-100 text-amber-700'
                            }`}>
                              {sub.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* FINANCES TAB */}
          {activeTab === 'finances' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-gradient-to-br from-indigo-500 to-blue-600 rounded-xl p-6 text-white shadow-lg">
                   <p className="text-blue-100 text-sm font-medium mb-1">Total Paid</p>
                   <h3 className="text-3xl font-bold">{CURRENCY_FORMATTER.format(studentData.feesPaid)}</h3>
                   <div className="mt-4 inline-flex items-center px-3 py-1 bg-white/20 rounded-full text-xs font-medium">
                      <CheckCircle className="w-3 h-3 mr-1" /> Verified
                   </div>
                </div>
                <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
                   <p className="text-gray-500 text-sm font-medium mb-1">Outstanding Balance</p>
                   <h3 className={`text-3xl font-bold ${studentData.totalFees - studentData.feesPaid > 0 ? 'text-red-500' : 'text-gray-900'}`}>
                      {CURRENCY_FORMATTER.format(studentData.totalFees - studentData.feesPaid)}
                   </h3>
                   <p className="text-xs text-gray-400 mt-2">Due Date: 15 Jan 2025</p>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-lg font-bold text-gray-900 mb-4">Payment History</h2>
                <table className="w-full text-sm text-left">
                    <thead className="bg-gray-50 text-gray-500 uppercase">
                      <tr>
                        <th className="px-4 py-3">Date</th>
                        <th className="px-4 py-3">Description</th>
                        <th className="px-4 py-3">Amount</th>
                        <th className="px-4 py-3">Status</th>
                        <th className="px-4 py-3">Receipt</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                       <tr>
                         <td className="px-4 py-3 text-gray-600">15 Nov 2024</td>
                         <td className="px-4 py-3 font-medium text-gray-900">Tuition Fee - Sem 5</td>
                         <td className="px-4 py-3 font-bold">₹50,000</td>
                         <td className="px-4 py-3"><span className="text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded text-xs font-bold">PAID</span></td>
                         <td className="px-4 py-3"><button className="text-blue-600 hover:underline flex items-center"><Download className="w-3 h-3 mr-1" /> Download</button></td>
                       </tr>
                       <tr>
                         <td className="px-4 py-3 text-gray-600">10 Aug 2024</td>
                         <td className="px-4 py-3 font-medium text-gray-900">Exam Fee</td>
                         <td className="px-4 py-3 font-bold">₹5,000</td>
                         <td className="px-4 py-3"><span className="text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded text-xs font-bold">PAID</span></td>
                         <td className="px-4 py-3"><button className="text-blue-600 hover:underline flex items-center"><Download className="w-3 h-3 mr-1" /> Download</button></td>
                       </tr>
                    </tbody>
                </table>
              </div>
            </div>
          )}

          {/* LIBRARY TAB */}
          {activeTab === 'library' && (
             <div className="space-y-6">
               <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                 <h2 className="text-lg font-bold text-gray-900 mb-4">Issued Books</h2>
                 <table className="w-full text-sm text-left">
                    <thead className="bg-gray-50 text-gray-500 uppercase">
                      <tr>
                        <th className="px-4 py-3">Book Name</th>
                        <th className="px-4 py-3">Author</th>
                        <th className="px-4 py-3">Issued Date</th>
                        <th className="px-4 py-3">Due Date</th>
                        <th className="px-4 py-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {MOCK_LIBRARY_BOOKS.map((book, idx) => (
                        <tr key={idx}>
                          <td className="px-4 py-3 font-medium text-gray-900">{book.title}</td>
                          <td className="px-4 py-3 text-gray-600">{book.author}</td>
                          <td className="px-4 py-3 text-gray-600">{book.issuedDate}</td>
                          <td className="px-4 py-3 text-gray-600">{book.dueDate}</td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 rounded-full text-xs font-semibold flex w-fit items-center ${
                              book.status === 'Overdue' ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'
                            }`}>
                              {book.status === 'Overdue' && <AlertTriangle className="w-3 h-3 mr-1" />}
                              {book.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                 </table>
               </div>
             </div>
          )}

          {/* HOSTEL TAB */}
          {activeTab === 'hostel' && (
            <div className="space-y-6">
               <div className="bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl shadow-sm border border-cyan-100 p-6">
                 <h2 className="text-lg font-bold text-gray-900 mb-6 flex items-center">
                   <Home className="w-5 h-5 mr-2 text-cyan-600" />
                   Room Allocation Status
                 </h2>
                 <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                   <div className="bg-white p-4 rounded-lg shadow-sm">
                      <p className="text-3xl font-bold text-cyan-600">{studentData.hostelRoom || '-'}</p>
                      <p className="text-xs text-gray-500 mt-1 uppercase tracking-wider">Room Number</p>
                   </div>
                   <div className="bg-white p-4 rounded-lg shadow-sm">
                      <p className="text-3xl font-bold text-cyan-600">{studentData.hostelRoom ? 'Block A' : '-'}</p>
                      <p className="text-xs text-gray-500 mt-1 uppercase tracking-wider">Block/Hostel</p>
                   </div>
                   <div className="bg-white p-4 rounded-lg shadow-sm">
                      <p className="text-3xl font-bold text-cyan-600">{studentData.hostelRoom ? '2/2' : '-'}</p>
                      <p className="text-xs text-gray-500 mt-1 uppercase tracking-wider">Occupancy</p>
                   </div>
                   <div className="bg-white p-4 rounded-lg shadow-sm">
                      <p className="text-3xl font-bold text-emerald-500">{studentData.hostelRoom ? 'Paid' : '-'}</p>
                      <p className="text-xs text-gray-500 mt-1 uppercase tracking-wider">Fee Status</p>
                   </div>
                 </div>
               </div>

               <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h2 className="text-lg font-bold text-gray-900 mb-4">Roommate Information</h2>
                  <table className="w-full text-sm text-left">
                     <thead className="bg-gray-50 text-gray-500 uppercase">
                        <tr>
                           <th className="px-4 py-3">Name</th>
                           <th className="px-4 py-3">Roll Number</th>
                           <th className="px-4 py-3">Branch</th>
                           <th className="px-4 py-3">Contact</th>
                        </tr>
                     </thead>
                     <tbody className="divide-y divide-gray-100">
                        <tr>
                           <td className="px-4 py-3 font-medium text-gray-900">Vikram Singh</td>
                           <td className="px-4 py-3 text-gray-600">STU-2024-005</td>
                           <td className="px-4 py-3 text-gray-600">B.Tech Civil</td>
                           <td className="px-4 py-3 text-blue-600">vikram.s@college.edu</td>
                        </tr>
                     </tbody>
                  </table>
               </div>
            </div>
          )}

        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default StudentPortal;
