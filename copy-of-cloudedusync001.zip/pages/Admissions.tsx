import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ApiService } from '../services/api';
import { Student } from '../types';
import { COURSES } from '../constants';
import { motion } from 'framer-motion';
import { UserPlus, Save, AlertCircle } from 'lucide-react';

const Admissions: React.FC = () => {
  const { refreshData } = useApp();
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<{type: 'success' | 'error', text: string} | null>(null);

  const [formData, setFormData] = useState<Partial<Student>>({
    fullName: '',
    email: '',
    phone: '',
    course: COURSES[0],
    batchYear: new Date().getFullYear().toString(),
    admissionDate: new Date().toISOString().split('T')[0],
    totalFees: 100000,
    feesPaid: 0,
    feeStatus: 'UNPAID',
    hostelRequired: false,
    hostelRoom: null
  });

  const validate = () => {
    if (!/^[6-9]\d{9}$/.test(formData.phone || '')) {
      return "Invalid Indian phone number. Must be 10 digits starting with 6-9.";
    }
    if (!formData.email?.includes('@')) {
      return "Invalid email address.";
    }
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const error = validate();
    if (error) {
      setMsg({ type: 'error', text: error });
      return;
    }

    setLoading(true);
    setMsg(null);

    const newStudent = { ...formData } as Student;
    const result = await ApiService.saveAdmission(newStudent);
    
    if (result.success) {
      setMsg({ type: 'success', text: 'Student admitted successfully! Database updated.' });
      setFormData({
        fullName: '',
        email: '',
        phone: '',
        course: COURSES[0],
        batchYear: new Date().getFullYear().toString(),
        admissionDate: new Date().toISOString().split('T')[0],
        totalFees: 100000,
        feesPaid: 0,
        feeStatus: 'UNPAID',
        hostelRequired: false,
        hostelRoom: null
      });
      await refreshData();
    } else {
      setMsg({ type: 'error', text: result.message || 'Failed to save.' });
    }
    setLoading(false);
  };

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 flex items-center">
          <UserPlus className="w-6 h-6 mr-3 text-blue-600" />
          New Admission
        </h1>
        <p className="text-gray-500 mt-1">Enroll a new student into the academic year.</p>
      </header>
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-xl shadow-sm border border-gray-100 p-8"
      >
        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="col-span-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Full Name <span className="text-red-500">*</span></label>
            <input 
              required
              type="text" 
              className="w-full rounded-lg border-gray-300 border p-3 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              placeholder="e.g. Rahul Sharma"
              value={formData.fullName}
              onChange={e => setFormData({...formData, fullName: e.target.value})}
            />
          </div>

          <div className="col-span-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Email <span className="text-red-500">*</span></label>
            <input 
              required
              type="email" 
              className="w-full rounded-lg border-gray-300 border p-3 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              placeholder="student@example.com"
              value={formData.email}
              onChange={e => setFormData({...formData, email: e.target.value})}
            />
          </div>

          <div className="col-span-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Phone (+91) <span className="text-red-500">*</span></label>
            <input 
              required
              type="text" 
              maxLength={10}
              placeholder="9876543210"
              className="w-full rounded-lg border-gray-300 border p-3 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              value={formData.phone}
              onChange={e => setFormData({...formData, phone: e.target.value.replace(/\D/g,'')})}
            />
          </div>

          <div className="col-span-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Course <span className="text-red-500">*</span></label>
            <select 
              className="w-full rounded-lg border-gray-300 border p-3 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              value={formData.course}
              onChange={e => setFormData({...formData, course: e.target.value})}
            >
              {COURSES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div className="col-span-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Total Course Fee (₹)</label>
            <input 
              type="number" 
              className="w-full rounded-lg border-gray-300 border p-3 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              value={formData.totalFees}
              onChange={e => setFormData({...formData, totalFees: Number(e.target.value)})}
            />
          </div>

          <div className="col-span-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Initial Payment (₹)</label>
            <input 
              type="number" 
              className="w-full rounded-lg border-gray-300 border p-3 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              value={formData.feesPaid}
              onChange={e => {
                const paid = Number(e.target.value);
                const status = paid >= (formData.totalFees || 0) ? 'PAID' : paid > 0 ? 'PARTIAL' : 'UNPAID';
                setFormData({...formData, feesPaid: paid, feeStatus: status});
              }}
            />
          </div>

          <div className="col-span-1 flex items-center pt-6">
             <label className="flex items-center space-x-3 cursor-pointer p-3 border rounded-lg w-full hover:bg-gray-50">
               <input 
                 type="checkbox" 
                 className="rounded text-blue-600 focus:ring-blue-500 h-5 w-5 border-gray-300"
                 checked={formData.hostelRequired}
                 onChange={e => setFormData({...formData, hostelRequired: e.target.checked})}
               />
               <span className="text-sm font-medium text-gray-700">Hostel Accommodation Required</span>
             </label>
          </div>

          <div className="col-span-1 md:col-span-2 mt-6">
            <button 
              disabled={loading}
              type="submit" 
              className={`w-full py-4 px-6 rounded-lg text-white font-bold text-lg shadow-md transition-all flex items-center justify-center ${
                loading ? 'bg-blue-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 hover:shadow-lg transform hover:-translate-y-1'
              }`}
            >
              {loading ? (
                'Processing Admission...' 
              ) : (
                <>
                  <Save className="w-5 h-5 mr-2" /> Confirm Admission
                </>
              )}
            </button>
          </div>
          
          {msg && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`col-span-1 md:col-span-2 p-4 rounded-lg flex items-center ${
                msg.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'
              }`}
            >
              {msg.type === 'error' && <AlertCircle className="w-5 h-5 mr-2" />}
              <span className="font-medium">{msg.text}</span>
            </motion.div>
          )}
        </form>
      </motion.div>
    </div>
  );
};

export default Admissions;