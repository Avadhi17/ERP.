import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';
import { motion } from 'framer-motion';
import { ShieldCheck, GraduationCap, Users, LogIn, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Login: React.FC = () => {
  const { login } = useApp();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate network delay
    setTimeout(() => {
      let role: UserRole | null = null;

      if (email === 'admin@example.edu' && password === 'Admin@123') {
        role = UserRole.ADMIN;
      } else if (email === 'faculty1@example.edu' && password === 'Faculty@123') {
        role = UserRole.FACULTY;
      } else if (email === 'student1@example.edu' && password === 'Student@123') {
        role = UserRole.STUDENT;
      }

      if (role) {
        login(email, role);
        navigate('/');
      } else {
        setError('Invalid credentials. Please check the demo accounts provided.');
      }
      setIsLoading(false);
    }, 800);
  };

  return (
    <div className="min-h-screen bg-slate-50 relative overflow-hidden flex items-center justify-center p-4">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-br from-blue-600 to-indigo-800 rounded-b-[3rem] shadow-2xl z-0"></div>
      <div className="absolute top-10 left-10 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
      <div className="absolute top-20 right-20 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl"></div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl z-10 overflow-hidden flex flex-col md:flex-row min-h-[550px]"
      >
        {/* Left Side: Branding */}
        <div className="md:w-5/12 bg-gradient-to-br from-blue-600 to-indigo-700 p-10 text-white flex flex-col justify-between relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center space-x-3 mb-8">
              <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center border border-white/30">
                <span className="font-bold text-xl">C</span>
              </div>
              <h1 className="text-xl font-bold tracking-tight">CloudEduSync</h1>
            </div>
            
            <h2 className="text-3xl font-bold mb-4 leading-tight">Welcome Back!</h2>
            <p className="text-blue-100 text-sm leading-relaxed">
              Sign in to manage admissions, academic records, and institutional data in one unified platform.
            </p>
          </div>

          <div className="relative z-10 mt-8 space-y-3">
             <div className="text-xs bg-white/10 p-3 rounded-lg border border-white/20">
                <p className="font-bold text-blue-200 mb-1">Demo Credentials:</p>
                <div className="grid grid-cols-2 gap-2 text-white/90">
                   <div>
                      <p className="font-semibold">Admin</p>
                      <p className="opacity-70">admin@example.edu</p>
                      <p className="opacity-70">Admin@123</p>
                   </div>
                   <div>
                      <p className="font-semibold">Faculty</p>
                      <p className="opacity-70">faculty1@example.edu</p>
                      <p className="opacity-70">Faculty@123</p>
                   </div>
                   <div className="col-span-2 mt-1">
                      <p className="font-semibold">Student</p>
                      <p className="opacity-70">student1@example.edu / Student@123</p>
                   </div>
                </div>
             </div>
          </div>

          {/* Decorative Circles */}
          <div className="absolute bottom-[-50px] right-[-50px] w-64 h-64 border-[30px] border-white/5 rounded-full"></div>
        </div>
        
        {/* Right Side: Login Form */}
        <div className="md:w-7/12 p-10 flex flex-col justify-center bg-white">
          <div className="mb-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Sign In</h3>
            <p className="text-gray-500 text-sm">Enter your institutional email and password.</p>
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }} 
              animate={{ opacity: 1, height: 'auto' }}
              className="mb-4 p-3 bg-red-50 text-red-700 text-sm rounded-lg flex items-center"
            >
              <AlertCircle className="w-4 h-4 mr-2" />
              {error}
            </motion.div>
          )}
          
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
              <input 
                type="email" 
                required
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none"
                placeholder="name@college.edu"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <input 
                type="password" 
                required
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center text-gray-600 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-gray-300 mr-2" />
                Remember me
              </label>
              <a href="#" className="text-blue-600 font-medium hover:underline">Forgot password?</a>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className={`w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold shadow-md hover:shadow-lg transition-all flex items-center justify-center ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {isLoading ? 'Authenticating...' : (
                <>
                  Sign In <LogIn className="w-4 h-4 ml-2" />
                </>
              )}
            </button>
          </form>
          
          <div className="mt-8 pt-6 border-t border-gray-100 text-center text-xs text-gray-400">
            Protected by CloudEduSync RBAC System v1.0
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Login;