import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ApiService } from '../services/api';
import { CURRENCY_FORMATTER } from '../constants';
import { Search, Wallet } from 'lucide-react';
import { UserRole } from '../types';

const Fees: React.FC = () => {
  const { students, refreshData, user } = useApp();
  const [search, setSearch] = useState('');
  const [processingId, setProcessingId] = useState<string | null>(null);

  if (user?.role !== UserRole.ADMIN) {
    return <div className="p-8 text-red-500">Unauthorized: Only Admins can manage fees.</div>;
  }

  const handleFeeUpdate = async (id: string, currentPaid: number, total: number) => {
    // Simple logic: If unpaid/partial -> make Paid full. If Paid -> Reset (toggle for MVP)
    const newAmount = currentPaid < total ? total : 0;
    const newStatus = newAmount === total ? 'PAID' : newAmount > 0 ? 'PARTIAL' : 'UNPAID';
    
    setProcessingId(id);
    await ApiService.updateFee(id, newAmount, newStatus);
    await refreshData();
    setProcessingId(null);
  };

  const filtered = students.filter(s => s.fullName.toLowerCase().includes(search.toLowerCase()) || s.id.includes(search));

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Fee Management</h1>
      
      <div className="mb-6 relative w-full md:w-1/3">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <input 
          type="text" 
          placeholder="Search student..."
          className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map(student => (
          <div key={student.id} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex flex-col">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-semibold text-gray-900">{student.fullName}</h3>
                <p className="text-xs text-gray-500">{student.id}</p>
              </div>
              <div className={`p-2 rounded-full ${student.feeStatus === 'PAID' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                <Wallet className="w-5 h-5" />
              </div>
            </div>
            
            <div className="space-y-2 mb-6">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Total Fee:</span>
                <span className="font-medium">{CURRENCY_FORMATTER.format(student.totalFees)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Paid:</span>
                <span className={`font-medium ${student.feesPaid < student.totalFees ? 'text-red-500' : 'text-green-600'}`}>
                  {CURRENCY_FORMATTER.format(student.feesPaid)}
                </span>
              </div>
            </div>

            <button
              onClick={() => handleFeeUpdate(student.id, student.feesPaid, student.totalFees)}
              disabled={processingId === student.id}
              className={`mt-auto w-full py-2 rounded-lg text-sm font-medium transition-colors ${
                student.feeStatus === 'PAID' 
                  ? 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  : 'bg-primary text-white hover:bg-primary/90'
              }`}
            >
              {processingId === student.id ? 'Updating...' : student.feeStatus === 'PAID' ? 'Mark Unpaid (Demo)' : 'Mark Full Paid'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Fees;
