
import React from 'react';
import { useApp } from '../context/AppContext';
import { Users, UserPlus, IndianRupee, BedDouble, TrendingUp, TrendingDown, BookOpen } from 'lucide-react';
import { motion } from 'framer-motion';
import { CURRENCY_FORMATTER } from '../constants';
import { UserRole } from '../types';

const MetricCard: React.FC<{ 
  title: string; 
  value: string; 
  subtext: string; 
  trend?: string;
  icon: any; 
  colorClass: string 
}> = ({ title, value, subtext, trend, icon: Icon, colorClass }) => (
  <motion.div 
    whileHover={{ y: -5 }}
    className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 relative overflow-hidden group"
  >
    <div className={`absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity ${colorClass.replace('bg-', 'text-')}`}>
      <Icon className="w-16 h-16" />
    </div>
    
    <div className="relative z-10">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-gray-500 font-semibold uppercase tracking-wider">{title}</p>
        <div className={`p-2 rounded-lg ${colorClass} text-white`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
      <h3 className="text-3xl font-bold text-gray-900">{value}</h3>
      
      <div className="flex items-center mt-2">
        {trend && (
           <span className="flex items-center text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded mr-2">
             <TrendingUp className="w-3 h-3 mr-1" /> {trend}
           </span>
        )}
        <p className="text-xs text-gray-400 font-medium">{subtext}</p>
      </div>
    </div>
  </motion.div>
);

const AdminDashboard: React.FC = () => {
  const { stats, user } = useApp();

  if (!stats || user?.role !== UserRole.ADMIN) return null;

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <header className="mb-8 flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-500 mt-1">Institutional overview and performance metrics.</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 shadow-sm">
            Download Report
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 shadow-md">
            + Quick Admission
          </button>
        </div>
      </header>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard 
          title="Total Students" 
          value={stats.totalStudents.toString()} 
          subtext="156 new this semester"
          trend="+5.2%"
          icon={Users} 
          colorClass="bg-blue-500" 
        />
        <MetricCard 
          title="Fee Collection" 
          value={CURRENCY_FORMATTER.format(stats.totalFeesCollected)} 
          subtext="78% of total expected"
          trend="+12%"
          icon={IndianRupee} 
          colorClass="bg-emerald-500" 
        />
        <MetricCard 
          title="Avg Attendance" 
          value={`${stats.avgAttendance}%`} 
          subtext="Up 3.1% vs last sem"
          trend="+3.1%"
          icon={TrendingUp} 
          colorClass="bg-amber-500" 
        />
        <MetricCard 
          title="Hostel Occupancy" 
          value={stats.hostelOccupancy.toString()} 
          subtext="Rooms available: 12"
          icon={BedDouble} 
          colorClass="bg-violet-500" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Performance Comparison Table */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-gray-900 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-blue-500" />
              Institutional Performance
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-gray-50 text-gray-500 uppercase font-semibold">
                <tr>
                  <th className="px-4 py-3">Metric</th>
                  <th className="px-4 py-3">Spring 2024</th>
                  <th className="px-4 py-3">Spring 2025</th>
                  <th className="px-4 py-3">Change</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                <tr>
                  <td className="px-4 py-3 font-medium text-gray-900">Average GPA</td>
                  <td className="px-4 py-3 text-gray-600">3.28</td>
                  <td className="px-4 py-3 text-gray-600 font-semibold">3.42</td>
                  <td className="px-4 py-3 text-emerald-600 font-bold">+0.14 ↑</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-medium text-gray-900">Overall Attendance</td>
                  <td className="px-4 py-3 text-gray-600">85.1%</td>
                  <td className="px-4 py-3 text-gray-600 font-semibold">88.2%</td>
                  <td className="px-4 py-3 text-emerald-600 font-bold">+3.1% ↑</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-medium text-gray-900">Course Pass Rate</td>
                  <td className="px-4 py-3 text-gray-600">82%</td>
                  <td className="px-4 py-3 text-gray-600 font-semibold">85%</td>
                  <td className="px-4 py-3 text-emerald-600 font-bold">+3.0% ↑</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-medium text-gray-900">Fee Compliance</td>
                  <td className="px-4 py-3 text-gray-600">72%</td>
                  <td className="px-4 py-3 text-gray-600 font-semibold">78%</td>
                  <td className="px-4 py-3 text-emerald-600 font-bold">+6.0% ↑</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Key Insights / Notifications */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-6 flex items-center">
            <BookOpen className="w-5 h-5 mr-2 text-amber-500" />
            Key Insights
          </h2>
          <div className="space-y-4">
            <div className="p-4 bg-emerald-50 rounded-lg border-l-4 border-emerald-500">
              <p className="text-sm font-bold text-emerald-800 mb-1">Fee Collection Improved</p>
              <p className="text-xs text-emerald-700">Collection increased to 78% this month, indicating better compliance.</p>
            </div>
            <div className="p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
              <p className="text-sm font-bold text-blue-800 mb-1">Higher Enrollments</p>
              <p className="text-xs text-blue-700">Computer Science saw a 15% jump in fresh admissions.</p>
            </div>
            <div className="p-4 bg-amber-50 rounded-lg border-l-4 border-amber-500">
              <p className="text-sm font-bold text-amber-800 mb-1">Library Due</p>
              <p className="text-xs text-amber-700">145 books are overdue this week. Notification sent to students.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
