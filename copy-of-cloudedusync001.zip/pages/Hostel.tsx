import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ApiService } from '../services/api';
import { HOSTEL_ROOMS } from '../constants';
import { UserRole } from '../types';

const Hostel: React.FC = () => {
  const { students, refreshData, user } = useApp();
  const [processingId, setProcessingId] = useState<string | null>(null);

  if (user?.role !== UserRole.ADMIN) {
    return <div className="p-8 text-red-500">Unauthorized.</div>;
  }

  // Filter students who requested hostel but have no room
  const pendingStudents = students.filter(s => s.hostelRequired && !s.hostelRoom);
  const allocatedStudents = students.filter(s => s.hostelRoom);

  const handleAllocation = async (studentId: string, room: string) => {
    if(!room) return;
    setProcessingId(studentId);
    await ApiService.updateHostel(studentId, room);
    await refreshData();
    setProcessingId(null);
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Hostel Allocation</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Pending Allocations */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <span className="w-2 h-2 rounded-full bg-red-500 mr-2"></span>
            Pending Requests ({pendingStudents.length})
          </h2>
          {pendingStudents.length === 0 ? (
            <p className="text-gray-400 text-sm">No pending requests.</p>
          ) : (
            <ul className="space-y-4">
              {pendingStudents.map(s => (
                <li key={s.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="mb-2 sm:mb-0">
                    <p className="font-medium text-gray-900">{s.fullName}</p>
                    <p className="text-xs text-gray-500">{s.id}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <select 
                      className="text-sm border-gray-300 rounded-md shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"
                      onChange={(e) => handleAllocation(s.id, e.target.value)}
                      defaultValue=""
                      disabled={processingId === s.id}
                    >
                      <option value="" disabled>Select Room</option>
                      {HOSTEL_ROOMS.map(r => (
                        <option key={r} value={r}>{r}</option>
                      ))}
                    </select>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Occupancy Status */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <span className="w-2 h-2 rounded-full bg-green-500 mr-2"></span>
            Current Occupancy
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-3 py-2 text-left text-gray-500">Room</th>
                  <th className="px-3 py-2 text-left text-gray-500">Student</th>
                  <th className="px-3 py-2 text-right text-gray-500">Action</th>
                </tr>
              </thead>
              <tbody>
                {allocatedStudents.map(s => (
                  <tr key={s.id} className="border-t border-gray-50">
                    <td className="px-3 py-3 font-medium text-primary">{s.hostelRoom}</td>
                    <td className="px-3 py-3 text-gray-700">{s.fullName}</td>
                    <td className="px-3 py-3 text-right">
                      <button 
                        onClick={() => handleAllocation(s.id, "")} // Logic to de-allocate would need slightly better API support, treating empty as null
                        className="text-xs text-red-500 hover:text-red-700"
                        disabled
                      >
                        (Vacate)
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Hostel;
