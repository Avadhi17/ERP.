
import { Student, DashboardStats, ApiResponse } from '../types';
import { GOOGLE_SCRIPT_URL } from '../constants';
import { INITIAL_STUDENTS } from './mockData';

// Simulated in-memory database for Mock Mode
let mockStudents = [...INITIAL_STUDENTS];

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const ApiService = {
  getStudents: async (): Promise<Student[]> => {
    if (!GOOGLE_SCRIPT_URL) {
      await delay(600);
      return [...mockStudents];
    }
    try {
      const res = await fetch(`${GOOGLE_SCRIPT_URL}?action=getStudents`);
      const json = await res.json();
      return json.data;
    } catch (e) {
      console.error("API Error", e);
      return [];
    }
  },

  saveAdmission: async (student: Student): Promise<ApiResponse<Student>> => {
    if (!GOOGLE_SCRIPT_URL) {
      await delay(800);
      const existingIndex = mockStudents.findIndex(s => s.id === student.id);
      
      if (existingIndex >= 0) {
        mockStudents[existingIndex] = student;
      } else {
        // Generate mock ID
        const newStudent = { 
          ...student, 
          id: `STU-2024-${String(mockStudents.length + 1).padStart(3, '0')}`,
          gpa: 0,
          attendance: 0,
          performance: 'Average' as any
        };
        mockStudents.push(newStudent);
        return { success: true, data: newStudent, message: 'Admission saved successfully (Mock)' };
      }
      return { success: true, data: student, message: 'Student updated successfully (Mock)' };
    }

    // Real Backend
    try {
      const res = await fetch(GOOGLE_SCRIPT_URL, {
        method: 'POST',
        body: JSON.stringify({ action: 'admission', data: student })
      });
      return await res.json();
    } catch (e) {
      return { success: false, message: 'Network error' };
    }
  },

  updateFee: async (id: string, amountPaid: number, status: string): Promise<ApiResponse<null>> => {
    if (!GOOGLE_SCRIPT_URL) {
      await delay(500);
      const idx = mockStudents.findIndex(s => s.id === id);
      if (idx >= 0) {
        mockStudents[idx].feesPaid = amountPaid;
        mockStudents[idx].feeStatus = status as any;
      }
      return { success: true, message: 'Fee updated (Mock)' };
    }

    try {
      const res = await fetch(GOOGLE_SCRIPT_URL, {
        method: 'POST',
        body: JSON.stringify({ action: 'fee', data: { id, amountPaid, status } })
      });
      return await res.json();
    } catch (e) {
      return { success: false, message: 'Network error' };
    }
  },

  updateHostel: async (id: string, room: string): Promise<ApiResponse<null>> => {
    if (!GOOGLE_SCRIPT_URL) {
      await delay(500);
      const idx = mockStudents.findIndex(s => s.id === id);
      if (idx >= 0) {
        mockStudents[idx].hostelRoom = room;
        mockStudents[idx].hostelRequired = true;
      }
      return { success: true, message: 'Room allocated (Mock)' };
    }

    try {
      const res = await fetch(GOOGLE_SCRIPT_URL, {
        method: 'POST',
        body: JSON.stringify({ action: 'hostel', data: { id, room } })
      });
      return await res.json();
    } catch (e) {
      return { success: false, message: 'Network error' };
    }
  },

  getDashboardStats: async (): Promise<DashboardStats> => {
    if (!GOOGLE_SCRIPT_URL) {
      await delay(400);
      const totalFees = mockStudents.reduce((acc, curr) => acc + (curr.feesPaid || 0), 0);
      const today = new Date().toISOString().split('T')[0];
      const todayAdmissions = mockStudents.filter(s => s.admissionDate === today).length;
      const occupiedBeds = mockStudents.filter(s => s.hostelRoom).length;
      
      const avgGPA = mockStudents.reduce((acc, curr) => acc + (curr.gpa || 0), 0) / mockStudents.length;
      const avgAttendance = mockStudents.reduce((acc, curr) => acc + (curr.attendance || 0), 0) / mockStudents.length;

      return {
        totalStudents: mockStudents.length,
        admissionsToday: todayAdmissions,
        totalFeesCollected: totalFees,
        hostelOccupancy: occupiedBeds,
        avgGPA: parseFloat(avgGPA.toFixed(2)),
        avgAttendance: parseFloat(avgAttendance.toFixed(1))
      };
    }
    
    try {
      const res = await fetch(`${GOOGLE_SCRIPT_URL}?action=dashboard`);
      const json = await res.json();
      return json.data;
    } catch (e) {
      return { 
        totalStudents: 0, 
        admissionsToday: 0, 
        totalFeesCollected: 0, 
        hostelOccupancy: 0,
        avgGPA: 0,
        avgAttendance: 0
      };
    }
  }
};
