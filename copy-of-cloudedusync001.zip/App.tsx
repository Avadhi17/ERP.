import React from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation, Outlet } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import { UserRole } from './types';
import Sidebar from './components/Sidebar';
import Login from './pages/Login';
import AdminDashboard from './pages/Dashboard';
import StudentPortal from './pages/StudentPortal';
import FacultyPortal from './pages/FacultyPortal';
import Admissions from './pages/Admissions';
import StudentList from './pages/StudentList';
import Fees from './pages/Fees';
import Hostel from './pages/Hostel';
import Unauthorized from './pages/Unauthorized';

// Protected Route Wrapper
const ProtectedRoute: React.FC<{ allowedRoles: UserRole[] }> = ({ allowedRoles }) => {
  const { user } = useApp();
  
  if (!user) return <Navigate to="/login" replace />;
  if (!allowedRoles.includes(user.role)) return <Navigate to="/unauthorized" replace />;

  return <Outlet />;
};

const MainLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useApp();
  if (!user) return null;

  return (
    <div className="flex min-h-screen bg-gray-50 font-sans">
      <Sidebar />
      <main className="flex-1 ml-64 transition-all duration-300">
        {children}
      </main>
    </div>
  );
};

const DashboardRouter: React.FC = () => {
  const { user } = useApp();
  if (!user) return null;

  switch (user.role) {
    case UserRole.ADMIN:
      return <AdminDashboard />;
    case UserRole.FACULTY:
      return <FacultyPortal />;
    case UserRole.STUDENT:
      return <StudentPortal />;
    default:
      return <Navigate to="/unauthorized" />;
  }
};

const AppRoutes: React.FC = () => {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/unauthorized" element={<Unauthorized />} />

      {/* Protected Routes */}
      <Route element={<MainLayout><Outlet /></MainLayout>}>
        
        {/* Shared Dashboard (Role specific view) */}
        <Route path="/" element={<ProtectedRoute allowedRoles={[UserRole.ADMIN, UserRole.FACULTY, UserRole.STUDENT]} />}>
           <Route index element={<DashboardRouter />} />
        </Route>

        {/* Admin & Faculty Shared */}
        <Route element={<ProtectedRoute allowedRoles={[UserRole.ADMIN, UserRole.FACULTY]} />}>
          <Route path="/admission" element={<Admissions />} />
          <Route path="/students" element={<StudentList />} />
        </Route>

        {/* Admin Only */}
        <Route element={<ProtectedRoute allowedRoles={[UserRole.ADMIN]} />}>
          <Route path="/fees" element={<Fees />} />
          <Route path="/hostel" element={<Hostel />} />
        </Route>

      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <HashRouter>
        <AppRoutes />
      </HashRouter>
    </AppProvider>
  );
};

export default App;