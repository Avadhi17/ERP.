// Replace this string with your deployed Google Apps Script Web App URL to use real backend.
// Leave empty to use the built-in Mock Data mode.
export const GOOGLE_SCRIPT_URL = ""; 

export const CURRENCY_FORMATTER = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0
});

export const HOSTEL_ROOMS = [
  'A-101', 'A-102', 'A-103', 'B-201', 'B-202', 'C-301', 'C-302'
];

export const COURSES = [
  'B.Tech Computer Science',
  'B.Tech Mechanical',
  'B.Tech Civil',
  'MBA',
  'BBA',
  'B.Sc Physics'
];
